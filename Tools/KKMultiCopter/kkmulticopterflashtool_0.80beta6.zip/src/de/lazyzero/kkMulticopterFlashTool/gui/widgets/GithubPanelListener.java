package de.lazyzero.kkMulticopterFlashTool.gui.widgets;

public interface GithubPanelListener {
	public void githubPanelChanged(int state);
}
